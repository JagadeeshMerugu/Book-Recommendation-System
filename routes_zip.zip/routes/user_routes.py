from flask import Blueprint, render_template
from flask_login import login_required, current_user

user = Blueprint('user', __name__)

# @user.route('/profile')
# @login_required
# def profile():
#     return render_template('profile.html', user=current_user)



from models import db, Book, Rating



@user.route('/profile')
@login_required
def profile():
    # Get user rated books
    rated_books = (
        db.session.query(Book, Rating.Book_Rating)
        .join(Rating, Book.ISBN == Rating.ISBN)
        .filter(Rating.User_ID == current_user.User_ID)
        .all()
    )
    return render_template('profile.html', user=current_user, rated_books=rated_books)
