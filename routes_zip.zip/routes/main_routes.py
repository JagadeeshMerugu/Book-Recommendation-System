from flask import Blueprint, render_template
from flask_login import current_user
from models.book import Book
from models import Rating
from models import db
from sqlalchemy.sql import func
from flask_login import login_required

main = Blueprint('main', __name__)
@login_required
@main.route('/')
def home():
    # Top 5 highest-rated books (average rating, at least 3 ratings)
    top_books = (
        db.session.query(Book, func.avg(Rating.Book_Rating).label('avg_rating'))
        .join(Rating, Book.ISBN == Rating.ISBN)
        .group_by(Book.ISBN)
        .having(func.count(Rating.Book_Rating) >= 3)
        .order_by(func.avg(Rating.Book_Rating).desc())
        .limit(5)
        .all()
    )

    # Split books from avg_rating
    featured_books = [{'book': b, 'rating': round(rating, 1)} for b, rating in top_books]

    return render_template('home.html', featured_books=featured_books)