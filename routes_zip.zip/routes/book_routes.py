from flask import Blueprint, render_template
from models.book import Book

book = Blueprint('book', __name__)

@book.route('/books')
def show_books():
    books = Book.query.all()
    return render_template('books.html', books=books)


# routes/book_routes.py

from flask import  jsonify, request # Blueprint
from flask_login import login_required, current_user
from models.rating import Rating
from models.user import User
#from models.book import Book
from app import db

from recommendation.hybrid import recommend_books



# @book.route('/recommend', methods=['GET'])
# @login_required
# def recommend():
#     user_id = current_user.User_ID

#     # Check if the user has rated any books
#     user_rated = Rating.query.filter_by(User_ID=user_id).first()
#     print('Checking User: ', user_rated)
#     user_has_ratings = user_rated is not None
#     print('Checking User: ', user_rated)
#     # For new users, check for title input
#     book_title = request.args.get('title') if not user_has_ratings else None

#     if not user_has_ratings and not book_title:
#         return jsonify({"error": "Please select a book title for recommendations."}), 400

#     recommended_isbns_or_books = recommend_books(
#         user_id=user_id,
#         user_has_ratings=user_has_ratings,
#         book_title=book_title,
#         k=20
#     )

#     print('Checking Recomendations: ', recommended_isbns_or_books)

#     if user_has_ratings:
#         if not recommended_isbns_or_books:
#             return jsonify([])

#         # CF - list of ISBNs
#         books = Book.query.filter(Book.ISBN.in_(recommended_isbns_or_books)).all()
#         results = [{
#             "title": book.Book_Title,
#             "author": book.Book_Author,
#             "genre": book.Genre,
#             "isbn": book.ISBN,
#             "image": book.Image_URL_M
#         } for book in books]

#     else:
#         # CBF - list of dicts
#         if not isinstance(recommended_isbns_or_books, list):
#             return jsonify([])

#         results = [{
#             "title": b.get('Book_Title', 'Unknown'),
#             "author": b.get('Book_Author', 'Unknown'),
#             "genre": b.get('Genre', 'N/A'),
#             "isbn": b.get('ISBN', ''),
#             "image": b.get('Image_URL_M', '')
#         } for b in recommended_isbns_or_books]

#     return jsonify(results)


    #return render_template('recommend_1.html')


@book.route('/recommend', methods=['GET'])
@login_required
def recommend():
    user_id = current_user.User_ID

    # Check if the user has rated any books
    user_rated = Rating.query.filter_by(User_ID=user_id).first()
    user_has_ratings = user_rated is not None

    # For new users, check for title input
    book_title = request.args.get('title') if not user_has_ratings else None

    if not user_has_ratings and not book_title:
        return jsonify({"error": "Please select a book title for recommendations."}), 400

    recommended_isbns_or_books = recommend_books(
        user_id=user_id,
        user_has_ratings=user_has_ratings,
        book_title=book_title,
        k=20
    )

    print('🔍 Recommendations:', recommended_isbns_or_books)

    # If it's a collaborative recommendation (old user)
    if user_has_ratings:
        # Ensure it's a list
        if not isinstance(recommended_isbns_or_books, list) or not recommended_isbns_or_books:
            return jsonify([])

        books = Book.query.filter(Book.ISBN.in_(recommended_isbns_or_books)).all()
        results = [{
            "title": book.Book_Title,
            "author": book.Book_Author,
            "genre": book.Genre,
            "isbn": book.ISBN,
            "image": book.Image_URL_M
        } for book in books]

    # If it's a content-based recommendation (new user)
    else:
        if not isinstance(recommended_isbns_or_books, list) or not recommended_isbns_or_books:
            return jsonify([])

        results = [{
            "title": b.get('Book_Title', 'Unknown'),
            "author": b.get('Book_Author', 'Unknown'),
            "genre": b.get('Genre', 'N/A'),
            "isbn": b.get('ISBN', ''),
            "image": b.get('Image_URL_M', '')
        } for b in recommended_isbns_or_books]

    return jsonify(results)



@book.route('/recommend-page')
@login_required
def recommend_page():
    user_id = current_user.User_ID
    has_ratings = Rating.query.filter_by(User_ID=user_id).first() is not None
    print('Checking value by book_route.py', has_ratings)
    return render_template('recommend.html', old_user=has_ratings)

    # user_id = current_user.id

    # # Example logic for old user (you can customize this)
    # # For example, consider user old if they rated 5 or more books
    # from models.rating import Rating  # import if needed
    # rating_count = Rating.query.filter_by(user_id=user_id).count()
    # old_user = rating_count >= 1

    # # ✅ Pass old_user to the template
    # return render_template('recommend.html', old_user=old_user)


@book.route('/api/book-titles')
@login_required
def book_titles():
    books = Book.query.with_entities(Book.Book_Title).limit(100).all()
    titles = [b.Book_Title for b in books]
    return jsonify(titles)


@book.route('/search-books')
@login_required
def search_books():
    query = request.args.get('q', '').lower()
    if not query:
        return jsonify([])

    books = Book.query.filter(
        (Book.Book_Title.ilike(f"%{query}%")) |
        (Book.Book_Author.ilike(f"%{query}%")) |
        (Book.Genre.ilike(f"%{query}%"))
    ).all()

    return jsonify([
        {
            "title": b.Book_Title,
            "author": b.Book_Author,
            "genre": b.Genre,
            "isbn": b.ISBN,
            "image": b.Image_URL_M
        }
        for b in books
    ])


from sqlalchemy import func

@book.route('/popular-books')
def popular_books():
    genre = request.args.get('genre')
    min_rating = float(request.args.get('min_rating', 0))
    min_count = int(request.args.get('min_count', 0))

    query = db.session.query(
        Book,
        func.avg(Rating.Book_Rating).label('avg_rating'),
        func.count(Rating.Book_Rating).label('num_ratings')
    ).join(Rating, Book.ISBN == Rating.ISBN)

    if genre:
        query = query.filter(Book.Genre == genre)

    query = query.group_by(Book.ISBN).having(
        func.avg(Rating.Book_Rating) >= min_rating,
    ).having(
        func.count(Rating.Book_Rating) >= min_count
    ).order_by(
        func.count(Rating.Book_Rating).desc(),
        func.avg(Rating.Book_Rating).desc()
    ).limit(20)

    results = query.all()

    # Get all genres for filter dropdown
    genres = db.session.query(Book.Genre).distinct().all()
    genres = [g[0] for g in genres]

    return render_template("popular_books.html", books=results, genres=genres,
                           selected_genre=genre, min_rating=min_rating, min_count=min_count)


# from models.reading_list import ReadingList

# @book.route('/book/<isbn>')
# @login_required
# def book_detail(isbn):
#     book = Book.query.filter_by(ISBN=isbn).first_or_404()

#     # Get user's previous rating (if any)
#     user_rating = Rating.query.filter_by(User_ID=current_user.User_ID, ISBN=isbn).first()

#     # Get user's reading status
    
#     status = ReadingList.query.filter_by(user_id=current_user.User_ID, isbn=isbn).first()

#     return render_template('book_detail.html', book=book, rating=user_rating, reading_status=status)



# @book.route('/update-reading-status', methods=['POST'])
# @login_required
# def update_reading_status():
#     isbn = request.form['isbn']
#     status = request.form['status']
#     user_id = current_user.User_ID

    
#     existing = ReadingList.query.filter_by(user_id=user_id, isbn=isbn).first()
#     if existing:
#         existing.status = status
#     else:
#         new = ReadingList(user_id=user_id, isbn=isbn, status=status)
#         db.session.add(new)

#     db.session.commit()
#     flash(f"Book marked as '{status.replace('_', ' ').title()}'")
#     return redirect(url_for('book.book_detail', isbn=isbn))

from models.reading_list import ReadingList

# @book.route('/book/<isbn>')
# @login_required
# def book_detail(isbn):
#     book = Book.query.filter_by(ISBN=isbn).first_or_404()

#     # Get reading status for this user and book
#     reading_status = ReadingList.query.filter_by(User_ID=current_user.User_ID, ISBN=book.ISBN).first()

#     # Get rating by this user for the book
#     rating = Rating.query.filter_by(User_ID=current_user.User_ID, ISBN=book.ISBN).first()

    

#     return render_template("book_details.html", book=book,
#                            reading_status=reading_status,
#                          rating=rating)


@book.route('/book/<isbn>')
@login_required
def book_details(isbn):
    book = Book.query.filter_by(ISBN=isbn).first_or_404()
    reading_status = ReadingList.query.filter_by(User_ID=current_user.User_ID, ISBN=isbn).first()
    rating = Rating.query.filter_by(User_ID=current_user.User_ID, ISBN=isbn).first()
    
    return render_template(
        'book_details.html',
        book=book,
        reading_status=reading_status,
        rating=rating
    )


# @book.route('/book/<isbn>')
# @login_required
# def book_detail(isbn):
#     book = Book.query.filter_by(ISBN=isbn).first_or_404()

#     # Get current reading status
#     reading_status = None
#     user_rating = None

#     if current_user.is_authenticated:
#         entry = ReadingList.query.filter_by(User_ID=current_user.User_ID, ISBN=isbn).first()
#         if entry:
#             reading_status = entry.status

#         # Get user's rating
#         rating_entry = Rating.query.filter_by(User_ID=current_user.User_ID, ISBN=isbn).first()
#         if rating_entry:
#             user_rating = rating_entry.Rating

#     return render_template("book_details.html", book=book,
#                            reading_status=reading_status,
#                            user_rating=user_rating)



from flask import url_for, redirect, flash

@book.route('/update-reading-status', methods=['POST'])
@login_required
def update_reading_status():
    isbn = request.form.get('isbn')
    status_map = {
        'want_to_read': 'Want to Read',
        'reading_now': 'Reading Now',
        'finished': 'Finished'
    }
    status_key = request.form.get('status')
    status = status_map.get(status_key)

    if not status:
        flash("Invalid reading status.")
        return redirect(request.referrer)

    book = Book.query.filter_by(ISBN=isbn).first()
    if not book:
        flash("Book not found.")
        return redirect(request.referrer)

    existing_entry = ReadingList.query.filter_by(User_ID=current_user.User_ID, ISBN=book.ISBN).first()
    if existing_entry:
        existing_entry.status = status
    else:
        new_entry = ReadingList(User_ID=current_user.User_ID, ISBN=book.ISBN, status=status)
        db.session.add(new_entry)

    db.session.commit()
    flash(f"Book marked as '{status}'.")
    return redirect(url_for('book.book_details', isbn=isbn))


from train_models_1 import train_all_models  # ✅ Import your training function
import threading  # ✅ For background training

@book.route('/rate-book', methods=['POST'])
@login_required
def rate_book():
    isbn = request.form.get('isbn')
    rating_val = int(request.form.get('rating'))

    if not (1 <= rating_val <= 10):
        flash("Rating must be between 1 and 10.")
        return redirect(request.referrer)

    book = Book.query.filter_by(ISBN=isbn).first()
    if not book:
        flash("Book not found.")
        return redirect(request.referrer)

    existing_rating = Rating.query.filter_by(User_ID=current_user.User_ID, ISBN=book.ISBN).first()
    if existing_rating:
        existing_rating.Book_Rating = rating_val
    else:
        new_rating = Rating(User_ID=current_user.User_ID, ISBN=book.ISBN, Book_Rating=rating_val)
        db.session.add(new_rating)

    db.session.commit()

    # ✅ Start retraining in the background
    threading.Thread(target=train_all_models).start()

    flash("Thank you for rating the book! Recommendations are updating.")

    # flash("Thank you for rating the book!")
    return redirect(url_for('book.book_details', isbn=isbn))  # ✅ Corrected line





@book.route('/reading-list')
@login_required
def reading_list():
    from models.reading_list import ReadingList
    results = db.session.query(Book, ReadingList.status).join(
        ReadingList, Book.ISBN == ReadingList.ISBN
    ).filter(ReadingList.User_ID == current_user.User_ID).all()

    # Group books in Python
    grouped = {
        'Want to Read': [],
        'Reading Now': [],
        'Finished': []
    }

    for book, status in results:
        if status in grouped:
            grouped[status].append(book)
    print(grouped)
    return render_template("reading_list.html", grouped=grouped)



@book.route('/search')
def search_page():
    all_books = Book.query.with_entities(Book.Book_Title).all()
    return render_template('search.html', all_books=all_books)


@book.route('/search-results')
@login_required
def search_results():
    query = request.args.get('query', '')
    results = Book.query.filter(
        (Book.Book_Title.ilike(f"%{query}%")) | (Book.Book_Author.ilike(f"%{query}%"))
    ).all()
    return render_template('search_results.html', query=query, results=results)


import pickle
import pandas as pd

@book.route('/recommend-similar/<isbn>')
@login_required
def recommend_similar_books(isbn):
    # Load the selected book from DB
    target_book = Book.query.filter_by(ISBN=isbn).first_or_404()

    # Load the trained TF-IDF model + book data
    with open('ml_models/tfidf_vectorizer.pkl', 'rb') as f:
        tfidf, cosine_sim, books_df = pickle.load(f)

    # Create index mapping
    books_df['title_lower'] = books_df['Book_Title'].str.lower()
    indices = pd.Series(books_df.index, index=books_df['title_lower']).drop_duplicates()

    # Get index for the book title
    title = target_book.Book_Title.lower()
    idx = indices.get(title)

    if idx is None:
        flash("Sorry, couldn't find similar books.")
        return redirect(url_for('book.search_page'))

    # Get top 5 similar books
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)[:6]
    book_indices = [i[0] for i in sim_scores]

    similar_books_info = books_df.iloc[book_indices]

    # Fetch corresponding books from DB by ISBN
    similar_books = Book.query.filter(Book.ISBN.in_(similar_books_info['ISBN'].tolist())).all()

    return render_template(
        'book_recommendations.html',
        base_book=target_book,
        recommended_books=similar_books
    )


# @book.route('/autocomplete')
# def autocomplete():
#     query = request.args.get('q', '').lower()
#     if not query:
#         return jsonify([])

#     results = Book.query.filter(Book.Book_Title.ilike(f'%{query}%')).limit(5).all()
#     suggestions = [book.Book_Title for book in results]
#     return jsonify(suggestions)

@book.route('/suggest', methods=['POST'])
def suggest():
    query = request.form.get('query', '').lower()
    suggestions = []

    if query:
        books = Book.query.with_entities(Book.Book_Title).filter(Book.Book_Title.ilike(f'%{query}%')).limit(5).all()
        suggestions = [book[0] for book in books]
    print("Suggestions : ", suggestions)

    return jsonify(suggestions)


