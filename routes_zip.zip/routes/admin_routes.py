from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from models.user import User
from models.book import Book
from models.rating import Rating

from models import db
from utils.decorators import admin_required

import matplotlib
matplotlib.use('Agg')  # Use non-GUI backend
import matplotlib.pyplot as plt



admin = Blueprint("admin", __name__, url_prefix="/admin")

# @admin.route("/dashboard")
# @login_required
# @admin_required
# def dashboard():
#     users = User.query.all()
#     books = Book.query.all()
#     ratings = Rating.query.all()
#     return render_template("admin/dashboard.html", users=users, books=books, ratings=ratings)

@admin.route('/dashboard')
@login_required
@admin_required  # your custom decorator
def dashboard():
    total_users = User.query.count()
    total_books = Book.query.count()
    total_ratings = Rating.query.count()
    

    # Genre count for chart
    genre_data = db.session.query(Book.Genre, db.func.count()).group_by(Book.Genre).all()
    # labels = [g[0] for g in genre_data]
    # counts = [g[1] for g in genre_data]

    return render_template("admin/dashboard.html",
                           total_users=total_users,
                           total_books=total_books,
                           total_ratings=total_ratings,
                           genre_data=genre_data)

    # genre_counts = db.session.query(Book.Genre, db.func.count(Book.ISBN)).group_by(Book.Genre).all()
    # return render_template("admin/dashboard.html", genre_data=genre_counts)




@admin.route("/users")
@login_required
@admin_required
def view_users():
    users = User.query.all()
    return render_template("admin/users.html", users=users)



# View all books
@admin.route('/books')
@login_required
@admin_required
def books():
    books = Book.query.all()
    return render_template('admin/books.html', books=books)

# Add book
@admin.route('/books/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_book():
    if request.method == 'POST':
        book = Book(
            ISBN=request.form['isbn'],
            Book_Title=request.form['title'],
            Book_Author=request.form['author'],
            Year_Of_Publication=int(request.form['year']),
            Publisher=request.form['publisher'],
            Image_URL_M=request.form['image_url'],
            Genre=request.form['genre']
        )
        db.session.add(book)
        db.session.commit()
        flash("Book added successfully!", "success")
        return redirect(url_for('admin.books'))
    return render_template('admin/add_book.html')

# Edit book
@admin.route('/books/edit/<isbn>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_book(isbn):
    book = Book.query.filter_by(ISBN=isbn).first_or_404()

    if request.method == 'POST':
        book.Book_Title = request.form['title']
        book.Book_Author = request.form['author']
        book.Year_Of_Publication = request.form['year']
        book.Publisher = request.form['publisher']
        book.Image_URL = request.form['image_url']
        book.Genre = request.form['genre']
        db.session.commit()
        flash("Book updated successfully!", "success")
        return redirect(url_for('admin.books'))

    return render_template('admin/edit_book.html', book=book)


# Delete book
@admin.route('/books/delete/<isbn>', methods=['POST'])
@login_required
@admin_required
def delete_book(isbn):
    book = Book.query.filter_by(ISBN=isbn).first_or_404()
    print("Deleting ISBN:", isbn)

    db.session.delete(book)
    db.session.commit()
    
    flash("Book deleted successfully!", "danger")
    return redirect(url_for('admin.books'))
    


# from flask import render_template, request, redirect, url_for, flash
# from models.user import User
# from models import db
# from flask_login import login_required
# from utils.decorators import admin_required
# from app import bcrypt
# from flask import Blueprint

import bcrypt
from sqlalchemy import func, or_


@admin.route('/admin/users/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_user():
    if request.method == 'POST':
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        username = request.form.get('username')
        email = request.form.get('email_id')
        password = request.form.get('password')
        role = request.form.get('role')
        location = request.form.get('location')
        age = request.form.get('age')

        existing_user = User.query.filter(
            or_(
                func.lower(User.username) == username.lower(),
                func.lower(User.email_id) == email.lower()
            )
        ).first()

        print("Existing user:", existing_user)

        if existing_user:
            flash("Username or email already exists. Please choose another.")
            return redirect(url_for('admin.add_user'))

        # Hash password
        #hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

        new_user = User(
            first_name=first_name,
            last_name=last_name,
            username=username,
            email_id=email,
            Location=location,
            Age=int(age),
            password=hashed_password,
            role=role
        )

        db.session.add(new_user)
        db.session.commit()
        flash('User added successfully!', 'success')
        return redirect(url_for('admin.view_users'))

    return render_template('admin/add_user.html')



import matplotlib.pyplot as plt
import os
import base64
import pandas as pd


@admin.route('/admin/analytics')
def admin_analytics():
    # Step 1: Load data from the database
    ratings = Rating.query.all()
    books = Book.query.all()
    users = User.query.all()

    # Step 2: Convert to DataFrame
    ratings_df = pd.DataFrame([{
        'User_ID': r.User_ID,
        'ISBN': r.ISBN,
        'Book_Rating': r.Book_Rating,
        'created_at': r.created_at
    } for r in ratings])

    books_df = pd.DataFrame([{
        'ISBN': b.ISBN,
        'Book_Title': b.Book_Title,
        'Genre': b.Genre
    } for b in books])

    users_df = pd.DataFrame([{
        'User_ID': u.User_ID,
        'Location': u.Location
    } for u in users])

    # Convert created_at to datetime
    ratings_df['created_at'] = pd.to_datetime(ratings_df['created_at'])

    # Folder to save plots
    img_dir = 'static/images'
    os.makedirs(img_dir, exist_ok=True)

    # Clear previous plots
    for file in ['monthly_trends.png', 'popular_genres.png', 'top_cities.png']:
        img_path = os.path.join(img_dir, file)
        if os.path.exists(img_path):
            os.remove(img_path)

    # --- 1. Monthly Rating Trends ---
    monthly_trends = ratings_df.set_index('created_at').resample('ME').count()['Book_Rating'].dropna()
    fig1, ax1 = plt.subplots()
    monthly_trends.plot(kind='line', ax=ax1, title='Monthly Rating Trends', marker='o')
    ax1.set_ylabel('Number of Ratings')
    fig1.tight_layout()
    fig1.savefig(os.path.join(img_dir, 'monthly_trends.png'))
    plt.close(fig1)

    # --- 2. Popular Genres ---
    merged = pd.merge(ratings_df, books_df, on='ISBN', how='left')
    genre_counts = merged['Genre'].value_counts().nlargest(10)
    fig2, ax2 = plt.subplots()
    genre_counts.plot(kind='bar', ax=ax2, title='Top 10 Popular Genres')
    ax2.set_ylabel('Number of Ratings')
    fig2.tight_layout()
    fig2.savefig(os.path.join(img_dir, 'popular_genres.png'))
    plt.close(fig2)

    # --- 3. Top Cities ---
    merged_users = pd.merge(ratings_df, users_df, on='User_ID', how='left')
    city_counts = merged_users['Location'].value_counts().nlargest(10)
    fig3, ax3 = plt.subplots()
    city_counts.plot(kind='barh', ax=ax3, title='Top Cities with Most Readers')
    ax3.set_xlabel('Number of Ratings')
    fig3.tight_layout()
    fig3.savefig(os.path.join(img_dir, 'top_cities.png'))
    plt.close(fig3)

    return render_template(
        'admin/analytics.html',
        monthly_trends_url='/static/images/monthly_trends.png',
        popular_genres_url='/static/images/popular_genres.png',
        top_cities_url='/static/images/top_cities.png'
    )

    # return render_template("admin/analytics.html",
    #     genres=genres, genre_counts=genre_counts,
    #     cities=cities, city_counts=city_counts,
    #     months=months, rating_counts=rating_counts
    # )