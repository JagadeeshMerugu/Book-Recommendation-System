from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required
from models.user import User
from app import db
# from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

auth = Blueprint('auth', __name__)

import bcrypt

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email_id=email).first()

        # ✅ bcrypt check
        if user and user.password and bcrypt.checkpw(password.encode('utf-8'), user.password.encode('utf-8')):
            login_user(user)
            return redirect(url_for('main.home'))
            #return render_template('home.html')

        flash('Invalid credentials')

    return render_template('login.html')





from sqlalchemy import or_, func

@auth.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email_id')
        password = request.form.get('password')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        location = request.form.get('location')
        age = request.form.get('age')

        print("Username:", username)
        print("Email:", email)

        existing_user = User.query.filter(
            or_(
                func.lower(User.username) == username.lower(),
                func.lower(User.email_id) == email.lower()
            )
        ).first()

        print("Existing user:", existing_user)

        if existing_user:
            flash("Username or email already exists. Please choose another.")
            return redirect(url_for('auth.signup'))

        # If new, hash password and create user
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        new_user = User(
            username=username,
            email_id=email,
            password=hashed_password,
            first_name=first_name,
            last_name=last_name,
            Location=location,
            Age=age,
            role='user'
        )
        db.session.add(new_user)
        db.session.commit()
        flash("Account created successfully. Please login.")
        return redirect(url_for('auth.login'))

    return render_template('register.html')


@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))


