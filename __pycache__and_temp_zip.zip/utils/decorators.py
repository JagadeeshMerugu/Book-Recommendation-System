from functools import wraps
from flask import redirect, url_for, flash
from flask_login import current_user

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.role:
            flash("You do not have access to this page.", "danger")
            return redirect(url_for('main.home'))  # Change 'main.home' to your homepage route
        return f(*args, **kwargs)
    return decorated_function

