
# Data processing helpers

import pandas as pd

def load_user_book_matrix(ratings_df):
    return ratings_df.pivot(index='User_ID', columns='ISBN', values='Rating').fillna(0)


