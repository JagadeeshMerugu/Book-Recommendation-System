import pandas as pd
from sklearn.neighbors import NearestNeighbors
import pickle
from models import Rating

def train_knn_model(ratings_df):
    user_book_matrix = ratings_df.pivot(index='User_ID', columns='ISBN', values='Book_Rating').fillna(0)
    knn = NearestNeighbors(metric='cosine', algorithm='brute')
    knn.fit(user_book_matrix.values)
    with open('ml_models/knn_model.pkl', 'wb') as f:
        pickle.dump((knn, user_book_matrix), f)

def get_knn_recommendations(user_id, k=20):
    #training = train_knn_model(Rating)
    with open('ml_models/knn_model.pkl', 'rb') as f:
        knn, user_book_matrix = pickle.load(f)
    if user_id not in user_book_matrix.index:
        return []
    user_index = user_book_matrix.index.get_loc(user_id)
    distances, indices = knn.kneighbors([user_book_matrix.loc[user_id].values], n_neighbors=k+1)
    recommended_users = indices.flatten()[1:]
    recommended_books = set()
    for idx in recommended_users:
        other_user_id = user_book_matrix.index[idx]
        user_ratings = user_book_matrix.loc[other_user_id]
        top_books = user_ratings[user_ratings > 0].sort_values(ascending=False).index.tolist()
        recommended_books.update(top_books)
    return list(recommended_books)[1:k]