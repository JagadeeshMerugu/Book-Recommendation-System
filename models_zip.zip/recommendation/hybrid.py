from recommendation.collaborative_knn import get_knn_recommendations
from recommendation.content_tfidf import get_similar_books

def recommend_books(user_id, user_has_ratings, book_title=None, k=20):
    if user_has_ratings:
        # Collaborative Filtering logic
        recommendations = get_knn_recommendations(user_id, k)
        if not recommendations:
            return [] #"Nothing to return or recommend"
        return recommendations  # list of ISBNs
    else:
        # Content-Based Filtering logic
        if not book_title:
            return [] # "No book title provided for new user"
        recommendations = get_similar_books(book_title, k)
        if not recommendations:
            return [] #"Nothing to return or recommend"
        return recommendations  # list of book dicts




# def recommend_books(user_id, user_has_ratings, book_title=None, k=5):
#     if user_has_ratings:
#         return get_knn_recommendations(user_id, k)
#     elif book_title:
#         return get_similar_books(book_title, k)
#     else:
#         return [] #"Nothig to return pr recommend" #[]