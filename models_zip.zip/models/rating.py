# from .. import db
from models import db 

class Rating(db.Model):
    __tablename__ = 'ratings'
    Rating_ID = db.Column(db.Integer, primary_key=True)
    User_ID = db.Column(db.Integer, db.ForeignKey('users.User_ID'))
    ISBN = db.Column(db.String(20), db.ForeignKey('books.ISBN'))
    Book_Rating = db.Column(db.Integer)
    created_at = db.Column(db.DateTime)
