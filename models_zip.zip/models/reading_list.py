from models import db

class ReadingList(db.Model):
    __tablename__ = 'reading_lists'

    id = db.Column(db.Integer, primary_key=True)
    User_ID = db.Column(db.Integer, db.ForeignKey('users.User_ID'), nullable=False)
    ISBN = db.Column(db.Integer, db.ForeignKey('books.ISBN'), nullable=False)
    status = db.Column(db.Enum('Want to Read', 'Reading Now', 'Finished'), nullable=False)
    added_at = db.Column(db.DateTime, server_default=db.func.now())

    __table_args__ = (db.UniqueConstraint('User_ID', 'ISBN', name='unique_user_book'),)
