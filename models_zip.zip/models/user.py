# from .. import db
from models import db 
from flask_login import UserMixin
from datetime import datetime



class User(db.Model, UserMixin):
    __tablename__ = 'users'
    User_ID = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50))
    last_name = db.Column(db.String(50))
    username = db.Column(db.String(50), unique=True)
    email_id = db.Column(db.String(100), unique=True)
    Location = db.Column(db.String(100))
    Age = db.Column(db.Integer)
    password = db.Column(db.String(100))
    created_at = db.Column(db.DateTime)
    role = db.Column(db.String(20), default='user')
    # Add default timestamp
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def get_id(self):
            return str(self.User_ID)  # Required by Flask-Login