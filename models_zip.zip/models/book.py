
from models import db 

class Book(db.Model):
    __tablename__ = 'books'
    id = db.Column(db.Integer, primary_key=True)
    ISBN = db.Column(db.String(20), unique=True)
    Book_Title = db.Column(db.String(255))
    Book_Author = db.Column(db.String(100))
    Year_Of_Publication = db.Column(db.Integer)
    Publisher = db.Column(db.String(255))
    Image_URL_M = db.Column(db.String(255))
    Genre = db.Column(db.String(100))
